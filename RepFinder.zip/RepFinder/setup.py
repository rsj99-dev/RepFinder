#!/usr/bin/env python3
"""Setup script for plasmid_rep_annotator package."""

from setuptools import setup, find_packages
import os

# Read README file
here = os.path.abspath(os.path.dirname(__file__))
try:
    with open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "Plasmid Rep Gene Annotator - A tool for annotating rep genes in plasmid sequences"

setup(
    name="plasmid-rep-annotator",
    version="1.0.0",
    description="A Python package for annotating rep genes in plasmid FASTA files",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="RepFinder",
    author_email="repfinder@example.com",
    url="https://github.com/repfinder/plasmid-rep-annotator",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    install_requires=[
        "biopython>=1.79",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=21.0",
            "flake8>=3.8",
        ],
    },
    entry_points={
        "console_scripts": [
            "plasmid-rep-annotator=plasmid_rep_annotator.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "plasmid_rep_annotator": ["*.fasta"],
    },
    zip_safe=False,
    keywords="bioinformatics plasmid rep gene annotation diamond blast",
)