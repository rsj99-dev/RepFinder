"""Biopython PairwiseAligner for protein sequence comparison."""

import os
from typing import Dict, List, Tuple
from Bio import SeqIO
from Bio.Align import PairwiseAligner
from Bio.Seq import Seq


class BioPythonAligner:
    """Biopython PairwiseAligner for protein sequence comparison."""
    
    def __init__(self, rep_database_path: str, identity_threshold: float = 15.0):
        """Initialize Biopython aligner.
        
        Args:
            rep_database_path: Path to rep.fasta database file
            identity_threshold: Minimum identity percentage for matches
        """
        self.rep_database_path = rep_database_path
        self.identity_threshold = identity_threshold
        self.rep_sequences = {}
        
        # Load rep database sequences
        self._load_rep_database()
        
        # Initialize PairwiseAligner with BLOSUM62 matrix
        self.aligner = PairwiseAligner()
        
        # Load BLOSUM62 matrix
        try:
            from Bio.Align import substitution_matrices
            blosum62 = substitution_matrices.load("BLOSUM62")
            self.aligner.substitution_matrix = blosum62
        except Exception as e:
            # Fallback to simple match/mismatch scoring if BLOSUM62 is not available
            print(f"Warning: Could not load BLOSUM62 matrix: {e}")
            print("Using simple match/mismatch scoring instead")
            self.aligner.match_score = 2
            self.aligner.mismatch_score = -1
            
        self.aligner.open_gap_score = -10
        self.aligner.extend_gap_score = -0.5
        self.aligner.mode = 'local'  # Local alignment like BLAST
    
    def _load_rep_database(self) -> None:
        """Load rep database sequences into memory.
        
        Raises:
            FileNotFoundError: If rep database file doesn't exist
        """
        if not os.path.exists(self.rep_database_path):
            raise FileNotFoundError(f"Rep database not found: {self.rep_database_path}")
        
        print(f"Loading rep database from {self.rep_database_path}...")
        try:
            for record in SeqIO.parse(self.rep_database_path, "fasta"):
                self.rep_sequences[record.id] = str(record.seq)
            print(f"Loaded {len(self.rep_sequences)} rep sequences")
        except Exception as e:
            raise RuntimeError(f"Failed to load rep database: {e}")
    
    def _calculate_identity(self, alignment) -> float:
        """Calculate sequence identity percentage from alignment.
        
        Args:
            alignment: Biopython alignment object
            
        Returns:
            Identity percentage (0-100)
        """
        if not alignment:
            return 0.0
        
        # Get aligned sequences
        aligned_query = alignment.aligned[0]
        aligned_target = alignment.aligned[1]
        
        # Count matches
        matches = 0
        total_positions = 0
        
        for query_segment, target_segment in zip(aligned_query, aligned_target):
            query_start, query_end = query_segment
            target_start, target_end = target_segment
            
            # Compare aligned segments
            query_seq = alignment.query[query_start:query_end]
            target_seq = alignment.target[target_start:target_end]
            
            for q_aa, t_aa in zip(query_seq, target_seq):
                if q_aa == t_aa:
                    matches += 1
                total_positions += 1
        
        if total_positions == 0:
            return 0.0
        
        return (matches / total_positions) * 100
    
    def _calculate_evalue(self, score: float, query_length: int, db_size: int) -> float:
        """Calculate approximate E-value from alignment score.
        
        This is a simplified E-value calculation for comparison purposes.
        
        Args:
            score: Alignment score
            query_length: Length of query sequence
            db_size: Total size of database
            
        Returns:
            Approximate E-value
        """
        # Simplified E-value calculation
        # In real BLAST, this involves complex statistical calculations
        # Here we use a simplified approximation for ranking purposes
        if score <= 0:
            return 1.0
        
        # Approximate E-value calculation
        # Higher scores get lower E-values
        effective_length = query_length * db_size
        evalue = effective_length / (2 ** (score / 10))
        
        return min(evalue, 1.0)
    
    def align_proteins(self, protein_sequences: Dict[str, str], output_dir: str = None) -> List[Tuple[str, str, float, float, int]]:
        """
Align protein sequences against rep database.
        
Args:
            protein_sequences: Dictionary of protein sequences
            output_dir: Directory for temporary files (not used in this implementation)
            
Returns:
            List of tuples (query_id, subject_id, identity, e_value, alignment_length)
        """
        if not protein_sequences:
            return []
        
        alignments = []
        total_db_size = sum(len(seq) for seq in self.rep_sequences.values())
        
        print(f"Aligning {len(protein_sequences)} proteins against {len(self.rep_sequences)} rep sequences...")
        
        for query_id, query_seq in protein_sequences.items():
            query_bio_seq = Seq(query_seq)
            
            for subject_id, subject_seq in self.rep_sequences.items():
                subject_bio_seq = Seq(subject_seq)
                
                # Perform pairwise alignment
                try:
                    alignment_results = self.aligner.align(query_bio_seq, subject_bio_seq)
                    
                    if alignment_results:
                        best_alignment = alignment_results[0]  # Get best alignment
                        
                        # Calculate identity
                        identity = self._calculate_identity(best_alignment)
                        
                        # Calculate approximate E-value
                        evalue = self._calculate_evalue(best_alignment.score, len(query_seq), total_db_size)
                        
                        # Filter by identity threshold and E-value threshold
                        if identity >= self.identity_threshold and evalue < 1e-3:
                            # Calculate alignment length (approximate)
                            alignment_length = min(len(query_seq), len(subject_seq))
                            
                            alignments.append((query_id, subject_id, identity, evalue, alignment_length))
                
                except Exception as e:
                    print(f"Warning: Alignment failed for {query_id} vs {subject_id}: {e}")
                    continue
        
        print(f"Found {len(alignments)} alignments above {self.identity_threshold}% identity")
        return alignments
    
    def get_rep_matches(self, protein_sequences: Dict[str, str], output_dir: str = None) -> Dict[str, List[Tuple[str, float, float]]]:
        """Get rep gene matches for protein sequences.
        
        Args:
            protein_sequences: Dictionary of protein sequences
            output_dir: Directory for temporary files (not used)
            
        Returns:
            Dictionary with protein IDs as keys and list of matches as values
            Each match is (subject_id, identity, e_value)
        """
        alignments = self.align_proteins(protein_sequences, output_dir)
        
        matches = {}
        for query_id, subject_id, identity, e_value, length in alignments:
            if query_id not in matches:
                matches[query_id] = []
            matches[query_id].append((subject_id, identity, e_value))
        
        # Sort matches by identity (descending)
        for query_id in matches:
            matches[query_id].sort(key=lambda x: x[1], reverse=True)
        
        return matches