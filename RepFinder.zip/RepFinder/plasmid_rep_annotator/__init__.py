"""Plasmid Rep Gene Annotator Package

A Python package for annotating rep genes in plasmid FASTA files.
This package identifies proteins >100 amino acids and compares them
against a rep gene database using DIAMOND alignment.
"""

__version__ = "1.0.0"
__author__ = "RepFinder"

from .annotator import PlasmidRepAnnotator
from .sequence_utils import FastaParser, DNATranslator
from .diamond_aligner import DiamondAligner

__all__ = ['PlasmidRepAnnotator', 'FastaParser', 'DNATranslator', 'DiamondAligner']