"""Main plasmid rep gene annotator."""

import os
import json
from typing import Dict, List, Tuple, Optional
from pathlib import Path
from datetime import datetime

from .sequence_utils import FastaParser, GenBankParser, DNATranslator
from .biopython_aligner import BioPythonAligner


class RepAnnotation:
    """Represents a rep gene annotation."""
    
    def __init__(self, plasmid_id: str, start: int, end: int, strand: int, 
                 protein_id: str, protein_sequence: str, rep_matches: List[Tuple[str, float, float]]):
        """Initialize rep annotation.
        
        Args:
            plasmid_id: ID of the plasmid sequence
            start: Start position of the gene
            end: End position of the gene
            strand: Strand direction (1 or -1)
            protein_id: ID of the protein
            protein_sequence: Amino acid sequence
            rep_matches: List of (rep_id, identity, e_value) matches
        """
        self.plasmid_id = plasmid_id
        self.start = start
        self.end = end
        self.strand = strand
        self.protein_id = protein_id
        self.protein_sequence = protein_sequence
        self.rep_matches = rep_matches
        
        # Get best match
        if rep_matches:
            self.best_match = max(rep_matches, key=lambda x: x[1])  # Sort by identity
            self.best_rep_id = self.best_match[0]
            self.best_identity = self.best_match[1]
            self.best_evalue = self.best_match[2]
        else:
            self.best_match = None
            self.best_rep_id = None
            self.best_identity = 0.0
            self.best_evalue = float('inf')
    
    def to_dict(self) -> Dict:
        """Convert annotation to dictionary."""
        return {
            'plasmid_id': self.plasmid_id,
            'start': self.start,
            'end': self.end,
            'strand': self.strand,
            'protein_id': self.protein_id,
            'protein_sequence': self.protein_sequence,
            'best_rep_id': self.best_rep_id,
            'best_identity': self.best_identity,
            'best_evalue': self.best_evalue,
            'all_matches': self.rep_matches
        }
    
    def to_gff3(self) -> str:
        """Convert annotation to GFF3 format."""
        attributes = f"ID={self.protein_id};Name=rep;product=replication protein;best_match={self.best_rep_id};identity={self.best_identity:.2f}"
        return f"{self.plasmid_id}\tRepFinder\tCDS\t{self.start+1}\t{self.end+1}\t{self.best_identity:.2f}\t{'+' if self.strand > 0 else '-'}\t0\t{attributes}"
    
    def to_genbank_feature(self) -> str:
        """Convert annotation to GenBank feature format."""
        location = f"{self.start+1}..{self.end+1}" if self.strand > 0 else f"complement({self.start+1}..{self.end+1})"
        feature = f"     CDS             {location}\n"
        feature += f"                     /gene=\"rep\"\n"
        feature += f"                     /product=\"replication protein\"\n"
        feature += f"                     /protein_id=\"{self.protein_id}\"\n"
        feature += f"                     /note=\"RepFinder annotation; best match: {self.best_rep_id}; identity: {self.best_identity:.2f}%\"\n"
        feature += f"                     /translation=\"{self.protein_sequence}\"\n"
        return feature


class PlasmidRepAnnotator:
    """Main class for annotating rep genes in plasmid sequences."""
    
    def __init__(self, rep_database_path: str = None, min_protein_length: int = 100, 
                 identity_threshold: float = 20.0, aligner_type: str = 'biopython'):
        """Initialize the annotator.
        
        Args:
            rep_database_path: Path to rep.fasta database
            min_protein_length: Minimum protein length in amino acids
            identity_threshold: Minimum identity percentage for rep matches
            aligner_type: Type of aligner to use (only 'biopython' is supported)
        """
        if rep_database_path is None:
            # Default to rep.fasta in the same directory as this package
            package_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            rep_database_path = os.path.join(package_dir, 'rep.fasta')
        
        self.rep_database_path = rep_database_path
        self.min_protein_length = min_protein_length
        self.identity_threshold = identity_threshold
        self.aligner_type = aligner_type
        
        # Initialize components
        self.fasta_parser = FastaParser()
        self.genbank_parser = GenBankParser()
        self.dna_translator = DNATranslator(min_protein_length=min_protein_length)
        
        # Initialize aligner based on type and availability
        self.aligner = self._initialize_aligner()
        
        # Verify rep database exists
        if not os.path.exists(self.rep_database_path):
            raise FileNotFoundError(f"Rep database not found: {self.rep_database_path}")
    
    def _initialize_aligner(self):
        """Initialize the BioPython aligner.
        
        Returns:
            Initialized aligner object
        """
        try:
            return BioPythonAligner(self.rep_database_path, identity_threshold=self.identity_threshold)
        except Exception as e:
            raise RuntimeError(f"Biopython aligner not available: {e}")
    
    def annotate_plasmid_file(self, plasmid_fasta_path: str, output_dir: str = None) -> List[RepAnnotation]:
        """Annotate rep genes in a plasmid FASTA file.
        
        Args:
            plasmid_fasta_path: Path to plasmid FASTA file
            output_dir: Directory for output files
            
        Returns:
            List of rep gene annotations
        """
        if output_dir is None:
            output_dir = os.path.dirname(plasmid_fasta_path)
        
        # Parse plasmid sequences
        print(f"Parsing plasmid sequences from {plasmid_fasta_path}...")
        plasmid_sequences = self.fasta_parser.parse_fasta(plasmid_fasta_path)
        print(f"Found {len(plasmid_sequences)} plasmid sequences")
        
        # Translate sequences to find ORFs
        print("Translating DNA sequences to find ORFs...")
        translated_sequences = self.dna_translator.translate_sequences(plasmid_sequences)
        
        # Get protein sequences
        protein_sequences = self.dna_translator.get_protein_sequences(translated_sequences)
        print(f"Found {len(protein_sequences)} proteins >= {self.min_protein_length} amino acids")
        
        if not protein_sequences:
            print("No proteins found meeting length criteria")
            return []
        
        # Align against rep database
        aligner_name = type(self.aligner).__name__.replace('Aligner', '')
        print(f"Aligning proteins against rep database using {aligner_name} ({self.rep_database_path})...")
        rep_matches = self.aligner.get_rep_matches(protein_sequences, output_dir)
        print(f"Found {len(rep_matches)} proteins with rep matches")
        
        # Create annotations
        annotations = []
        for seq_id, orfs in translated_sequences.items():
            for i, (start, end, frame, protein_seq) in enumerate(orfs):
                protein_id = f"{seq_id}_orf_{i+1}_frame_{frame}_{start}_{end}"
                
                if protein_id in rep_matches:
                    annotation = RepAnnotation(
                        plasmid_id=seq_id,
                        start=start,
                        end=end,
                        strand=1 if frame > 0 else -1,
                        protein_id=protein_id,
                        protein_sequence=protein_seq,
                        rep_matches=rep_matches[protein_id]
                    )
                    annotations.append(annotation)
        
        print(f"Created {len(annotations)} rep gene annotations")
        return annotations
    
    def annotate_genbank_file(self, genbank_file_path: str, output_dir: str = None) -> List[RepAnnotation]:
        """Annotate rep genes in a GenBank file.
        
        Args:
            genbank_file_path: Path to GenBank file
            output_dir: Directory for output files
            
        Returns:
            List of rep gene annotations
        """
        if output_dir is None:
            output_dir = os.path.dirname(genbank_file_path)
        
        # Parse GenBank sequences
        print(f"Parsing GenBank sequences from {genbank_file_path}...")
        plasmid_sequences = self.genbank_parser.parse_genbank(genbank_file_path)
        print(f"Found {len(plasmid_sequences)} plasmid sequences")
        
        # Get existing features for comparison
        try:
            existing_features = self.genbank_parser.get_genbank_features(genbank_file_path)
            print(f"Extracted existing features from GenBank file")
        except Exception as e:
            print(f"Warning: Could not extract features from GenBank file: {e}")
            existing_features = {}
        
        # Translate sequences to find ORFs
        print("Translating DNA sequences to find ORFs...")
        translated_sequences = self.dna_translator.translate_sequences(plasmid_sequences)
        
        # Get protein sequences
        protein_sequences = self.dna_translator.get_protein_sequences(translated_sequences)
        print(f"Found {len(protein_sequences)} proteins >= {self.min_protein_length} amino acids")
        
        if not protein_sequences:
            print("No proteins found meeting length criteria")
            return []
        
        # Align against rep database
        aligner_name = type(self.aligner).__name__.replace('Aligner', '')
        print(f"Aligning proteins against rep database using {aligner_name} ({self.rep_database_path})...")
        rep_matches = self.aligner.get_rep_matches(protein_sequences, output_dir)
        print(f"Found {len(rep_matches)} proteins with rep matches")
        
        # Create annotations
        annotations = []
        for seq_id, orfs in translated_sequences.items():
            for i, (start, end, frame, protein_seq) in enumerate(orfs):
                protein_id = f"{seq_id}_orf_{i+1}_frame_{frame}_{start}_{end}"
                
                if protein_id in rep_matches:
                    annotation = RepAnnotation(
                        plasmid_id=seq_id,
                        start=start,
                        end=end,
                        strand=1 if frame > 0 else -1,
                        protein_id=protein_id,
                        protein_sequence=protein_seq,
                        rep_matches=rep_matches[protein_id]
                    )
                    annotations.append(annotation)
        
        print(f"Created {len(annotations)} rep gene annotations")
        
        # Compare with existing annotations if available
        if existing_features:
            self._compare_with_existing_features(annotations, existing_features)
        
        return annotations
    
    def _compare_with_existing_features(self, new_annotations: List[RepAnnotation], existing_features: Dict[str, List[Dict]]) -> None:
        """Compare new annotations with existing GenBank features.
        
        Args:
            new_annotations: List of new rep annotations
            existing_features: Dictionary of existing GenBank features
        """
        print("\nComparing with existing GenBank features:")
        
        for ann in new_annotations:
            plasmid_features = existing_features.get(ann.plasmid_id, [])
            
            # Look for overlapping CDS features
            overlapping_features = []
            for feature in plasmid_features:
                if feature['type'] == 'CDS':
                    # Check for overlap
                    if (ann.start < feature['end'] and ann.end > feature['start']):
                        overlapping_features.append(feature)
            
            if overlapping_features:
                print(f"  {ann.protein_id}: Found {len(overlapping_features)} overlapping CDS feature(s)")
                for feature in overlapping_features:
                    product = feature['qualifiers'].get('product', ['unknown'])[0]
                    gene = feature['qualifiers'].get('gene', [''])[0]
                    print(f"    - {feature['start']}-{feature['end']}: {product} {gene}")
            else:
                print(f"  {ann.protein_id}: No overlapping features found (novel rep gene candidate)")
    
    def save_annotations(self, annotations: List[RepAnnotation], output_prefix: str, plasmid_sequences: Dict[str, str] = None) -> None:
        """Save annotations to files.
        
        Args:
            annotations: List of annotations
            output_prefix: Prefix for output files
            plasmid_sequences: Dictionary of plasmid sequences for GenBank output
        """
        if not annotations:
            print("No annotations to save")
            return
        
        # Save as JSON
        json_file = f"{output_prefix}_rep_annotations.json"
        with open(json_file, 'w') as f:
            json.dump([ann.to_dict() for ann in annotations], f, indent=2)
        print(f"Saved JSON annotations to {json_file}")
        
        # Save as GFF3
        gff3_file = f"{output_prefix}_rep_annotations.gff3"
        with open(gff3_file, 'w') as f:
            f.write("##gff-version 3\n")
            f.write("##source RepFinder\n")
            for ann in annotations:
                f.write(ann.to_gff3() + "\n")
        print(f"Saved GFF3 annotations to {gff3_file}")
        
        # Save as GenBank
        if plasmid_sequences:
            gb_file = f"{output_prefix}_rep_annotations.gb"
            self.save_genbank(annotations, plasmid_sequences, gb_file)
            print(f"Saved GenBank annotations to {gb_file}")
        
        # Save summary
        summary_file = f"{output_prefix}_rep_summary.txt"
        with open(summary_file, 'w') as f:
            f.write(f"Rep Gene Annotation Summary\n")
            f.write(f"========================\n\n")
            f.write(f"Total rep genes found: {len(annotations)}\n")
            f.write(f"Minimum protein length: {self.min_protein_length} aa\n")
            f.write(f"Identity threshold: {self.identity_threshold}%\n\n")
            
            for ann in annotations:
                f.write(f"Plasmid: {ann.plasmid_id}\n")
                f.write(f"  Position: {ann.start+1}-{ann.end+1} ({'forward' if ann.strand > 0 else 'reverse'})\n")
                f.write(f"  Protein: {ann.protein_id}\n")
                f.write(f"  Best match: {ann.best_rep_id} ({ann.best_identity:.2f}% identity)\n")
                f.write(f"  E-value: {ann.best_evalue:.2e}\n")
                f.write(f"  Protein length: {len(ann.protein_sequence)} aa\n\n")
        
        print(f"Saved summary to {summary_file}")
    
    def save_genbank(self, annotations: List[RepAnnotation], plasmid_sequences: Dict[str, str], output_file: str) -> None:
        """Save annotations in GenBank format.
        
        Args:
            annotations: List of annotations
            plasmid_sequences: Dictionary of plasmid sequences
            output_file: Output GenBank file path
        """
        with open(output_file, 'w') as f:
            # Group annotations by plasmid
            plasmid_annotations = {}
            for ann in annotations:
                if ann.plasmid_id not in plasmid_annotations:
                    plasmid_annotations[ann.plasmid_id] = []
                plasmid_annotations[ann.plasmid_id].append(ann)
            
            # Write each plasmid as a separate GenBank record
            for plasmid_id, anns in plasmid_annotations.items():
                if plasmid_id not in plasmid_sequences:
                    continue
                
                sequence = plasmid_sequences[plasmid_id]
                seq_length = len(sequence)
                
                # Header
                f.write(f"LOCUS       {plasmid_id:<16} {seq_length:>8} bp    DNA     circular BCT {datetime.now().strftime('%d-%b-%Y').upper()}\n")
                f.write(f"DEFINITION  {plasmid_id} with RepFinder annotations.\n")
                f.write(f"ACCESSION   {plasmid_id}\n")
                f.write(f"VERSION     {plasmid_id}.1\n")
                f.write(f"KEYWORDS    plasmid; replication protein.\n")
                f.write(f"SOURCE      .\n")
                f.write(f"  ORGANISM  .\n")
                f.write(f"COMMENT     Annotated using RepFinder - Plasmid Rep Gene Annotator\n")
                f.write(f"            Minimum protein length: {self.min_protein_length} aa\n")
                f.write(f"            Identity threshold: {self.identity_threshold}%\n")
                f.write(f"FEATURES             Location/Qualifiers\n")
                f.write(f"     source          1..{seq_length}\n")
                f.write(f"                     /organism=\"unknown\"\n")
                f.write(f"                     /mol_type=\"genomic DNA\"\n")
                f.write(f"                     /plasmid=\"{plasmid_id}\"\n")
                
                # Features
                for ann in sorted(anns, key=lambda x: x.start):
                    f.write(ann.to_genbank_feature())
                
                # Origin (sequence)
                f.write(f"ORIGIN\n")
                for i in range(0, len(sequence), 60):
                    line_num = i + 1
                    seq_line = sequence[i:i+60]
                    # Format sequence in groups of 10
                    formatted_seq = ' '.join([seq_line[j:j+10] for j in range(0, len(seq_line), 10)])
                    f.write(f"{line_num:>9} {formatted_seq.lower()}\n")
                
                f.write("//\n")
                if plasmid_id != list(plasmid_annotations.keys())[-1]:  # Not the last one
                    f.write("\n")
    
    def detect_file_format(self, file_path: str) -> str:
        """Detect file format based on extension and content.
        
        Args:
            file_path: Path to the file
            
        Returns:
            File format ('fasta' or 'genbank')
        """
        file_ext = os.path.splitext(file_path)[1].lower()
        
        # Check by extension first
        if file_ext in ['.gb', '.gbk', '.genbank']:
            return 'genbank'
        elif file_ext in ['.fa', '.fasta', '.fas', '.fna']:
            return 'fasta'
        
        # If extension is ambiguous, check file content
        try:
            with open(file_path, 'r') as f:
                first_line = f.readline().strip()
                if first_line.startswith('LOCUS'):
                    return 'genbank'
                elif first_line.startswith('>'):
                    return 'fasta'
        except:
            pass
        
        # Default to fasta if uncertain
        return 'fasta'
    
    def annotate_file(self, file_path: str, output_dir: str = None) -> List[RepAnnotation]:
        """Annotate rep genes in a plasmid file (auto-detect format).
        
        Args:
            file_path: Path to plasmid file (FASTA or GenBank)
            output_dir: Directory for output files
            
        Returns:
            List of rep gene annotations
        """
        file_format = self.detect_file_format(file_path)
        print(f"Detected file format: {file_format.upper()}")
        
        if file_format == 'genbank':
            return self.annotate_genbank_file(file_path, output_dir)
        else:
            return self.annotate_plasmid_file(file_path, output_dir)
    
    def annotate_and_save(self, plasmid_file_path: str, output_prefix: str = None) -> List[RepAnnotation]:
        """Annotate plasmid file and save results (supports FASTA and GenBank).
        
        Args:
            plasmid_file_path: Path to plasmid file (FASTA or GenBank)
            output_prefix: Prefix for output files (default: input filename)
            
        Returns:
            List of rep gene annotations
        """
        if output_prefix is None:
            output_prefix = os.path.splitext(plasmid_file_path)[0]
        
        # Detect file format and parse sequences
        file_format = self.detect_file_format(plasmid_file_path)
        
        if file_format == 'genbank':
            plasmid_sequences = self.genbank_parser.parse_genbank(plasmid_file_path)
            annotations = self.annotate_genbank_file(plasmid_file_path)
        else:
            plasmid_sequences = self.fasta_parser.parse_fasta(plasmid_file_path)
            annotations = self.annotate_plasmid_file(plasmid_file_path)
        
        # Save results
        self.save_annotations(annotations, output_prefix, plasmid_sequences)
        
        return annotations