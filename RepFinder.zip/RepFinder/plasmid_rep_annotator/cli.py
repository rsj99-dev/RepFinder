#!/usr/bin/env python3
"""Command line interface for plasmid rep gene annotator."""

import argparse
import sys
import os
from pathlib import Path

from .annotator import PlasmidRepAnnotator


def main():
    """Main command line interface."""
    parser = argparse.ArgumentParser(
        description="Annotate rep genes in plasmid FASTA or GenBank files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples:
  # Basic usage with FASTA file (auto-detect aligner)
  python -m plasmid_rep_annotator.cli input.fasta
  
  # Annotate GenBank file
  python -m plasmid_rep_annotator.cli input.gb
  
  # Force use BLAST+ instead of DIAMOND
  python -m plasmid_rep_annotator.cli input.fasta --aligner blast
  
  # Specify custom rep database
  python -m plasmid_rep_annotator.cli input.fasta --rep-db custom_rep.fasta
  
  # Adjust parameters
  python -m plasmid_rep_annotator.cli input.fasta --min-length 50 --identity 20
  
  # Specify output prefix
  python -m plasmid_rep_annotator.cli input.fasta --output results/my_analysis
"""
    )
    
    parser.add_argument(
        'input_file',
        help='Input plasmid file (FASTA or GenBank format)'
    )
    
    parser.add_argument(
        '--rep-db',
        default=None,
        help='Path to rep gene database FASTA file (default: rep.fasta in package directory)'
    )
    
    parser.add_argument(
        '--min-length',
        type=int,
        default=100,
        help='Minimum protein length in amino acids (default: 100)'
    )
    
    parser.add_argument(
        '--identity',
        type=float,
        default=15.0,
        help='Minimum identity percentage for rep matches (default: 15.0)'
    )
    
    parser.add_argument(
        '--aligner',
        choices=['auto', 'diamond', 'blast'],
        default='auto',
        help='Sequence aligner to use: auto (try DIAMOND first, then BLAST+), diamond (DIAMOND only), blast (BLAST+ only) (default: auto)'
    )
    
    parser.add_argument(
        '--output', '-o',
        default=None,
        help='Output prefix for result files (default: input filename without extension)'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='%(prog)s 1.0.0'
    )
    
    args = parser.parse_args()
    
    # Validate input file
    if not os.path.exists(args.input_file):
        print(f"Error: Input file '{args.input_file}' not found", file=sys.stderr)
        sys.exit(1)
    
    # Set output prefix
    if args.output is None:
        args.output = os.path.splitext(args.input_file)[0]
    
    # Create output directory if needed
    output_dir = os.path.dirname(args.output)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    try:
        # Initialize annotator
        print("Initializing plasmid rep gene annotator...")
        annotator = PlasmidRepAnnotator(
            rep_database_path=args.rep_db,
            min_protein_length=args.min_length,
            identity_threshold=args.identity,
            aligner_type=args.aligner
        )
        
        print(f"Using rep database: {annotator.rep_database_path}")
        print(f"Minimum protein length: {args.min_length} amino acids")
        print(f"Identity threshold: {args.identity}%")
        print()
        
        # Run annotation
        annotations = annotator.annotate_and_save(args.input_file, args.output)
        
        # Print summary
        print()
        print("=" * 50)
        print("ANNOTATION COMPLETE")
        print("=" * 50)
        print(f"Input file: {args.input_file}")
        print(f"Rep genes found: {len(annotations)}")
        
        if annotations:
            print("\nRep gene summary:")
            for i, ann in enumerate(annotations, 1):
                print(f"  {i}. {ann.plasmid_id} ({ann.start+1}-{ann.end+1}) - {ann.best_rep_id} ({ann.best_identity:.1f}% identity)")
        
        print(f"\nOutput files:")
        print(f"  - {args.output}_rep_annotations.json")
        print(f"  - {args.output}_rep_annotations.gff3")
        print(f"  - {args.output}_rep_summary.txt")
        
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()