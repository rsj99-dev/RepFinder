"""Sequence processing utilities for FASTA and GenBank parsing and DNA translation."""

import re
from typing import Dict, List, Tuple, Generator
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord


class FastaParser:
    """Parser for FASTA files."""
    
    @staticmethod
    def parse_fasta(file_path: str) -> Dict[str, str]:
        """Parse FASTA file and return sequences as dictionary.
        
        Args:
            file_path: Path to FASTA file
            
        Returns:
            Dictionary with sequence IDs as keys and sequences as values
        """
        sequences = {}
        try:
            for record in SeqIO.parse(file_path, "fasta"):
                sequences[record.id] = str(record.seq)
        except Exception as e:
            raise ValueError(f"Error parsing FASTA file {file_path}: {e}")
        
        return sequences
    
    @staticmethod
    def write_fasta(sequences: Dict[str, str], output_path: str) -> None:
        """Write sequences to FASTA file.
        
        Args:
            sequences: Dictionary with sequence IDs as keys and sequences as values
            output_path: Path to output FASTA file
        """
        records = []
        for seq_id, sequence in sequences.items():
            record = SeqRecord(Seq(sequence), id=seq_id, description="")
            records.append(record)
        
        with open(output_path, 'w') as output_file:
            SeqIO.write(records, output_file, "fasta")


class GenBankParser:
    """Parser for GenBank files."""
    
    @staticmethod
    def parse_genbank(file_path: str) -> Dict[str, str]:
        """Parse GenBank file and return sequences as dictionary.
        
        Args:
            file_path: Path to GenBank file
            
        Returns:
            Dictionary with sequence IDs as keys and sequences as values
        """
        sequences = {}
        try:
            for record in SeqIO.parse(file_path, "genbank"):
                # Use record.id or record.name as the key
                seq_id = record.id if record.id else record.name
                if not seq_id:
                    seq_id = f"sequence_{len(sequences) + 1}"
                sequences[seq_id] = str(record.seq)
        except Exception as e:
            raise ValueError(f"Error parsing GenBank file {file_path}: {e}")
        
        return sequences
    
    @staticmethod
    def get_genbank_features(file_path: str) -> Dict[str, List[Dict]]:
        """Extract features from GenBank file.
        
        Args:
            file_path: Path to GenBank file
            
        Returns:
            Dictionary with sequence IDs as keys and lists of feature dictionaries as values
        """
        features_dict = {}
        try:
            for record in SeqIO.parse(file_path, "genbank"):
                seq_id = record.id if record.id else record.name
                if not seq_id:
                    seq_id = f"sequence_{len(features_dict) + 1}"
                
                features = []
                for feature in record.features:
                    feature_dict = {
                        'type': feature.type,
                        'location': str(feature.location),
                        'start': int(feature.location.start),
                        'end': int(feature.location.end),
                        'strand': feature.location.strand,
                        'qualifiers': dict(feature.qualifiers)
                    }
                    features.append(feature_dict)
                
                features_dict[seq_id] = features
        except Exception as e:
            raise ValueError(f"Error parsing GenBank features from {file_path}: {e}")
        
        return features_dict


class DNATranslator:
    """DNA sequence translator."""
    
    def __init__(self, min_protein_length: int = 100):
        """Initialize translator.
        
        Args:
            min_protein_length: Minimum protein length in amino acids
        """
        self.min_protein_length = min_protein_length
    
    def find_orfs(self, dna_sequence: str) -> List[Tuple[int, int, int, str]]:
        """Find all open reading frames (ORFs) in DNA sequence.
        
        Args:
            dna_sequence: DNA sequence string
            
        Returns:
            List of tuples (start, end, frame, protein_sequence)
        """
        orfs = []
        dna_seq = Seq(dna_sequence.upper())
        
        # Check all 6 reading frames (3 forward, 3 reverse)
        for frame in range(3):
            # Forward strand
            self._find_orfs_in_frame(str(dna_seq), frame, 1, orfs)
            # Reverse strand
            self._find_orfs_in_frame(str(dna_seq.reverse_complement()), frame, -1, orfs, len(dna_sequence))
        
        return orfs
    
    def _find_orfs_in_frame(self, sequence: str, frame: int, strand: int, orfs: List, seq_length: int = None) -> None:
        """Find ORFs in a specific reading frame.
        
        Args:
            sequence: DNA sequence
            frame: Reading frame (0, 1, or 2)
            strand: Strand direction (1 for forward, -1 for reverse)
            orfs: List to append found ORFs
            seq_length: Length of original sequence (for reverse strand)
        """
        seq = Seq(sequence[frame:])
        
        # Translate sequence
        try:
            protein = str(seq.translate())
        except:
            return
        
        # Find ORFs between start and stop codons
        start_codons = ['M']  # Methionine
        stop_codon = '*'
        
        i = 0
        while i < len(protein):
            if protein[i] in start_codons:
                # Found start codon, look for stop codon
                start_pos = i
                j = i + 1
                while j < len(protein) and protein[j] != stop_codon:
                    j += 1
                
                if j < len(protein):  # Found stop codon
                    orf_protein = protein[start_pos:j]
                    if len(orf_protein) >= self.min_protein_length:
                        # Calculate DNA coordinates
                        if strand == 1:
                            dna_start = frame + start_pos * 3
                            dna_end = frame + j * 3 + 2
                        else:
                            dna_end = seq_length - (frame + start_pos * 3)
                            dna_start = seq_length - (frame + j * 3 + 2)
                        
                        orfs.append((dna_start, dna_end, strand * (frame + 1), orf_protein))
                    i = j
                else:
                    break
            else:
                i += 1
    
    def translate_sequences(self, sequences: Dict[str, str]) -> Dict[str, List[Tuple[int, int, int, str]]]:
        """Translate DNA sequences to find proteins.
        
        Args:
            sequences: Dictionary of DNA sequences
            
        Returns:
            Dictionary with sequence IDs as keys and lists of ORFs as values
        """
        translated = {}
        
        for seq_id, dna_sequence in sequences.items():
            orfs = self.find_orfs(dna_sequence)
            if orfs:  # Only include sequences with ORFs
                translated[seq_id] = orfs
        
        return translated
    
    def get_protein_sequences(self, translated_sequences: Dict[str, List[Tuple[int, int, int, str]]]) -> Dict[str, str]:
        """Extract protein sequences from translated ORFs.
        
        Args:
            translated_sequences: Dictionary of translated sequences
            
        Returns:
            Dictionary with protein IDs as keys and protein sequences as values
        """
        proteins = {}
        
        for seq_id, orfs in translated_sequences.items():
            for i, (start, end, frame, protein_seq) in enumerate(orfs):
                protein_id = f"{seq_id}_orf_{i+1}_frame_{frame}_{start}_{end}"
                proteins[protein_id] = protein_seq
        
        return proteins