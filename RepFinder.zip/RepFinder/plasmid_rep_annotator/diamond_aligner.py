"""DIAMOND aligner for protein sequence comparison."""

import os
import subprocess
import tempfile
from typing import Dict, List, Tuple
from pathlib import Path


class DiamondAligner:
    """DIAMOND protein sequence aligner."""
    
    def __init__(self, rep_database_path: str, identity_threshold: float = 15.0):
        """Initialize DIAMOND aligner.
        
        Args:
            rep_database_path: Path to rep.fasta database file
            identity_threshold: Minimum identity percentage for matches
        """
        self.rep_database_path = rep_database_path
        self.identity_threshold = identity_threshold
        self.diamond_db_path = None
        
        # Check if DIAMOND is available
        if not self._check_diamond_available():
            raise RuntimeError("DIAMOND is not available. Please install DIAMOND and ensure it's in PATH.")
    
    def _check_diamond_available(self) -> bool:
        """Check if DIAMOND is available in system PATH.
        
        Returns:
            True if DIAMOND is available, False otherwise
        """
        try:
            result = subprocess.run(['diamond', '--version'], 
                                  capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False
    
    def create_diamond_database(self, output_dir: str = None) -> str:
        """Create DIAMOND database from rep.fasta file.
        
        Args:
            output_dir: Directory to store database files
            
        Returns:
            Path to created database
        """
        if output_dir is None:
            output_dir = os.path.dirname(self.rep_database_path)
        
        db_name = os.path.splitext(os.path.basename(self.rep_database_path))[0]
        self.diamond_db_path = os.path.join(output_dir, f"{db_name}.dmnd")
        
        # Create DIAMOND database
        cmd = [
            'diamond', 'makedb',
            '--in', self.rep_database_path,
            '--db', self.diamond_db_path.replace('.dmnd', '')
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            if result.returncode != 0:
                raise RuntimeError(f"Failed to create DIAMOND database: {result.stderr}")
        except subprocess.TimeoutExpired:
            raise RuntimeError("DIAMOND database creation timed out")
        
        return self.diamond_db_path
    
    def align_proteins(self, protein_sequences: Dict[str, str], output_dir: str = None) -> List[Tuple[str, str, float, float, int]]:
        """Align protein sequences against rep database.
        
        Args:
            protein_sequences: Dictionary of protein sequences
            output_dir: Directory for temporary files
            
        Returns:
            List of tuples (query_id, subject_id, identity, e_value, alignment_length)
        """
        if not protein_sequences:
            return []
        
        # Create database if not exists
        if self.diamond_db_path is None or not os.path.exists(self.diamond_db_path):
            self.create_diamond_database(output_dir)
        
        # Create temporary files
        with tempfile.TemporaryDirectory() as temp_dir:
            query_file = os.path.join(temp_dir, "query.fasta")
            output_file = os.path.join(temp_dir, "alignment.tsv")
            
            # Write query sequences to file
            self._write_protein_fasta(protein_sequences, query_file)
            
            # Run DIAMOND alignment
            cmd = [
                'diamond', 'blastp',
                '--db', self.diamond_db_path.replace('.dmnd', ''),
                '--query', query_file,
                '--out', output_file,
                '--outfmt', '6', 'qseqid', 'sseqid', 'pident', 'evalue', 'length',
                '--max-target-seqs', '10',
                '--evalue', '1e-5'
            ]
            
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
                if result.returncode != 0:
                    raise RuntimeError(f"DIAMOND alignment failed: {result.stderr}")
            except subprocess.TimeoutExpired:
                raise RuntimeError("DIAMOND alignment timed out")
            
            # Parse results
            return self._parse_alignment_results(output_file)
    
    def _write_protein_fasta(self, protein_sequences: Dict[str, str], output_path: str) -> None:
        """Write protein sequences to FASTA file.
        
        Args:
            protein_sequences: Dictionary of protein sequences
            output_path: Output file path
        """
        with open(output_path, 'w') as f:
            for seq_id, sequence in protein_sequences.items():
                f.write(f">{seq_id}\n{sequence}\n")
    
    def _parse_alignment_results(self, results_file: str) -> List[Tuple[str, str, float, float, int]]:
        """Parse DIAMOND alignment results.
        
        Args:
            results_file: Path to results file
            
        Returns:
            List of alignment results
        """
        alignments = []
        
        if not os.path.exists(results_file):
            return alignments
        
        with open(results_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    parts = line.split('\t')
                    if len(parts) >= 5:
                        query_id = parts[0]
                        subject_id = parts[1]
                        identity = float(parts[2])
                        e_value = float(parts[3])
                        length = int(parts[4])
                        
                        # Filter by identity threshold
                        if identity >= self.identity_threshold:
                            alignments.append((query_id, subject_id, identity, e_value, length))
        
        return alignments
    
    def get_rep_matches(self, protein_sequences: Dict[str, str], output_dir: str = None) -> Dict[str, List[Tuple[str, float, float]]]:
        """Get rep gene matches for protein sequences.
        
        Args:
            protein_sequences: Dictionary of protein sequences
            output_dir: Directory for temporary files
            
        Returns:
            Dictionary with protein IDs as keys and list of matches as values
            Each match is (subject_id, identity, e_value)
        """
        alignments = self.align_proteins(protein_sequences, output_dir)
        
        matches = {}
        for query_id, subject_id, identity, e_value, length in alignments:
            if query_id not in matches:
                matches[query_id] = []
            matches[query_id].append((subject_id, identity, e_value))
        
        return matches