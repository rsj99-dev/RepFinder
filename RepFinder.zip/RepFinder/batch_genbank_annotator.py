#!/usr/bin/env python3
"""
GenBank文件批量注释工具
批量处理目录中的GenBank和FASTA文件，进行质粒复制子基因注释
"""

import os
import sys
from pathlib import Path
from typing import List, Dict, Optional
import json
from datetime import datetime

from plasmid_rep_annotator.annotator import PlasmidRepAnnotator


class BatchGenBankAnnotator:
    """GenBank文件批量注释器"""
    
    def __init__(self, rep_database_path=None, min_protein_length=100, 
                 identity_threshold=20.0, aligner_type='biopython'):
        """
        初始化批量注释器
        
        Args:
            rep_database_path: rep基因数据库路径
            min_protein_length: 最小蛋白质长度
            identity_threshold: 同源性阈值
            aligner_type: 比对工具类型
        """
        self.annotator = PlasmidRepAnnotator(
            rep_database_path=rep_database_path,
            min_protein_length=min_protein_length,
            identity_threshold=identity_threshold,
            aligner_type=aligner_type
        )
        
    def process_directory(self, input_dir: str, output_dir: str = None, 
                         file_extensions: List[str] = None) -> Dict[str, int]:
        """
        批量处理目录中的GenBank和FASTA文件
        
        Args:
            input_dir: 输入目录
            output_dir: 输出目录，如果为None则使用输入目录下的'batch_results'子目录
            file_extensions: 要处理的文件扩展名列表
            
        Returns:
            处理统计信息
        """
        if file_extensions is None:
            file_extensions = ['.gb', '.gbk', '.genbank', '.fasta', '.fa', '.fna']
        
        if output_dir is None:
            output_dir = os.path.join(input_dir, 'batch_results')
        
        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)
        
        stats = {
            'total_files': 0,
            'processed_files': 0,
            'failed_files': 0,
            'total_rep_genes': 0
        }
        
        # 获取所有符合条件的文件
        input_path = Path(input_dir)
        all_files = []
        for ext in file_extensions:
            all_files.extend(list(input_path.glob(f'*{ext}')))
            all_files.extend(list(input_path.glob(f'*{ext.upper()}')))
        
        stats['total_files'] = len(all_files)
        
        if stats['total_files'] == 0:
            print(f"在目录 {input_dir} 中未找到支持的文件格式")
            print(f"支持的扩展名: {', '.join(file_extensions)}")
            return stats
        
        failed_files = []
        all_annotations = []
        
        print(f"找到 {stats['total_files']} 个文件待处理")
        print("=" * 60)
        
        for i, file_path in enumerate(all_files, 1):
            print(f"[{i}/{stats['total_files']}] 处理文件: {file_path.name}")
            
            try:
                # 设置输出前缀
                output_prefix = os.path.join(output_dir, file_path.stem)
                
                # 运行注释
                annotations = self.annotator.annotate_and_save(str(file_path), output_prefix)
                
                stats['processed_files'] += 1
                stats['total_rep_genes'] += len(annotations)
                
                # 收集注释信息用于汇总报告
                file_info = {
                    'filename': file_path.name,
                    'filepath': str(file_path),
                    'rep_genes_count': len(annotations),
                    'annotations': [{
                        'plasmid_id': ann.plasmid_id,
                        'start': ann.start + 1,  # 转换为1-based坐标
                        'end': ann.end + 1,
                        'best_rep_id': ann.best_rep_id,
                        'best_identity': ann.best_identity
                    } for ann in annotations]
                }
                all_annotations.append(file_info)
                
                print(f"  ✓ 成功处理，找到 {len(annotations)} 个rep基因")
                
            except Exception as e:
                stats['failed_files'] += 1
                failed_files.append({'filename': file_path.name, 'error': str(e)})
                print(f"  ✗ 处理失败: {e}")
        
        # 生成汇总报告
        self.generate_batch_report(stats, failed_files, all_annotations, output_dir)
        
        return stats
    
    def generate_batch_report(self, stats: Dict[str, int], failed_files: List[Dict], 
                             all_annotations: List[Dict], output_dir: str):
        """
        生成批量处理报告
        
        Args:
            stats: 统计信息
            failed_files: 失败的文件列表
            all_annotations: 所有注释结果
            output_dir: 输出目录
        """
        # 生成文本报告
        report_file = Path(output_dir) / "batch_annotation_report.txt"
        
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write("GenBank文件批量注释报告\n")
                f.write("=" * 50 + "\n\n")
                f.write(f"处理时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                f.write(f"总文件数: {stats['total_files']}\n")
                f.write(f"成功处理: {stats['processed_files']}\n")
                f.write(f"失败文件数: {stats['failed_files']}\n")
                f.write(f"总rep基因数: {stats['total_rep_genes']}\n\n")
                
                if stats['total_files'] > 0:
                    success_rate = (stats['processed_files'] / stats['total_files']) * 100
                    f.write(f"成功率: {success_rate:.1f}%\n\n")
                
                # 详细结果
                f.write("详细处理结果:\n")
                f.write("-" * 30 + "\n")
                for file_info in all_annotations:
                    f.write(f"文件: {file_info['filename']}\n")
                    f.write(f"  Rep基因数: {file_info['rep_genes_count']}\n")
                    if file_info['annotations']:
                        for ann in file_info['annotations']:
                            f.write(f"    - {ann['plasmid_id']} ({ann['start']}-{ann['end']}) - {ann['best_rep_id']} ({ann['best_identity']:.1f}% identity)\n")
                    f.write("\n")
                
                if failed_files:
                    f.write("失败的文件:\n")
                    f.write("-" * 30 + "\n")
                    for file_info in failed_files:
                        f.write(f"  {file_info['filename']}: {file_info['error']}\n")
                    f.write("\n")
                
                f.write("说明:\n")
                f.write("-" * 10 + "\n")
                f.write("1. 每个文件的注释结果保存在对应的JSON、GFF3和TXT文件中\n")
                f.write("2. 支持的文件格式: GenBank (.gb, .gbk, .genbank) 和 FASTA (.fasta, .fa, .fna)\n")
                f.write("3. 输出文件以原文件名为前缀，添加相应的后缀\n")
                f.write("4. 此报告汇总了所有文件的处理结果\n")
            
            print(f"\n批量处理报告已保存到: {report_file}")
            
        except Exception as e:
            print(f"生成报告失败: {e}")
        
        # 生成JSON格式的汇总结果
        json_report_file = Path(output_dir) / "batch_annotation_summary.json"
        try:
            summary_data = {
                'processing_time': datetime.now().isoformat(),
                'statistics': stats,
                'results': all_annotations,
                'failed_files': failed_files
            }
            
            with open(json_report_file, 'w', encoding='utf-8') as f:
                json.dump(summary_data, f, indent=2, ensure_ascii=False)
            
            print(f"JSON汇总文件已保存到: {json_report_file}")
            
        except Exception as e:
            print(f"生成JSON汇总文件失败: {e}")


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='批量注释GenBank和FASTA文件中的质粒复制子基因',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""示例:
  # 批量处理目录中的所有GenBank和FASTA文件
  python batch_genbank_annotator.py input_directory
  
  # 指定输出目录
  python batch_genbank_annotator.py input_directory -o output_directory
  
  # 调整参数
  python batch_genbank_annotator.py input_directory --min-length 50 --identity 20
  
  # 只处理特定格式的文件
  python batch_genbank_annotator.py input_directory --extensions .gb .gbk
"""
    )
    
    parser.add_argument('input_dir', help='包含GenBank/FASTA文件的输入目录')
    parser.add_argument('-o', '--output', help='输出目录（默认为输入目录下的batch_results子目录）')
    
    parser.add_argument(
        '--rep-db',
        default=None,
        help='rep基因数据库路径（默认使用内置数据库）'
    )
    
    parser.add_argument(
        '--min-length',
        type=int,
        default=100,
        help='最小蛋白质长度（默认: 100）'
    )
    
    parser.add_argument(
        '--identity',
        type=float,
        default=20.0,
        help='最小同源性百分比（默认: 20.0）'
    )
    
    parser.add_argument(
        '--aligner',
        choices=['biopython'],
        default='biopython',
        help='序列比对工具（默认: biopython）'
    )
    
    parser.add_argument(
        '--extensions',
        nargs='+',
        default=['.gb', '.gbk', '.genbank', '.fasta', '.fa', '.fna'],
        help='要处理的文件扩展名（默认: .gb .gbk .genbank .fasta .fa .fna）'
    )
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input_dir):
        print(f"错误: 输入目录不存在: {args.input_dir}")
        sys.exit(1)
    
    if not os.path.isdir(args.input_dir):
        print(f"错误: {args.input_dir} 不是一个目录")
        sys.exit(1)
    
    try:
        # 初始化批量注释器
        print("初始化批量GenBank注释器...")
        batch_annotator = BatchGenBankAnnotator(
            rep_database_path=args.rep_db,
            min_protein_length=args.min_length,
            identity_threshold=args.identity,
            aligner_type=args.aligner
        )
        
        print(f"使用rep数据库: {batch_annotator.annotator.rep_database_path}")
        print(f"最小蛋白质长度: {args.min_length} 氨基酸")
        print(f"同源性阈值: {args.identity}%")
        print(f"支持的文件扩展名: {', '.join(args.extensions)}")
        print()
        
        # 开始批量处理
        print(f"开始批量处理 {args.input_dir} 中的文件...")
        stats = batch_annotator.process_directory(
            args.input_dir, 
            args.output, 
            args.extensions
        )
        
        # 打印最终统计
        print("\n" + "=" * 60)
        print("批量处理完成!")
        print(f"总文件数: {stats['total_files']}")
        print(f"成功处理: {stats['processed_files']}")
        print(f"失败文件数: {stats['failed_files']}")
        print(f"总rep基因数: {stats['total_rep_genes']}")
        
        if stats['total_files'] > 0:
            success_rate = (stats['processed_files'] / stats['total_files']) * 100
            print(f"成功率: {success_rate:.1f}%")
        
        output_dir = args.output if args.output else os.path.join(args.input_dir, 'batch_results')
        print(f"\n结果已保存到: {output_dir}")
        
    except Exception as e:
        print(f"批量处理过程中出错: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()